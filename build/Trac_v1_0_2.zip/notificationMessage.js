/**
 * Object for sending the notifications
 * 
 * @author jose antony <joseantony007@gmail.com>
 */
var notificationMessage = {
	title: '',
	text: '',
	icon: ''
};